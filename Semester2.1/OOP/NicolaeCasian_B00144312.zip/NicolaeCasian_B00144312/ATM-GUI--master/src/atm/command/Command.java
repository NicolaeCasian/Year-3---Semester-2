package atm.command;

public interface Command {
    void execute();  // Method to execute the command
}
