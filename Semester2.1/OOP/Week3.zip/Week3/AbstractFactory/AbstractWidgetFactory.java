
//AbstractFactory
//Abstract class for creating a Window Widget
public abstract class AbstractWidgetFactory{
  public abstract Window createWindow(String title);
}















