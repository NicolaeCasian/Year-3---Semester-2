//Abstract class to 
public abstract class Window{
    //Protected String and void function
    protected String title;
    public abstract void repaint();
}







