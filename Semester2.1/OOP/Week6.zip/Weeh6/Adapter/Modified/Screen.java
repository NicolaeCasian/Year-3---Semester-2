import java.io.*;

public class Screen{
	public void writeInt(String i)	{
		System.out.print(i);
	}

	public void nextLine(){
		System.out.println("");
	}
}
