import java.io.*;


public class Client{
	public static void main(String[] args){
		Screen scr = new Screen();

        scr.writeInt(10);
		scr.nextLine();
	}
}
