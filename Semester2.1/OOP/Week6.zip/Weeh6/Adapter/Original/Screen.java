import java.io.*;

public class Screen{
	public static void writeInt(int i)	{
		System.out.print(i);
	}

	public static void nextLine(){
		System.out.println("");
	}
}



