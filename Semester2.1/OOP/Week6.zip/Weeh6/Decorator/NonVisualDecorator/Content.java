public abstract class Content{
    //Abstract method to be implemented by the concrete classes
    public void show(){}
}
