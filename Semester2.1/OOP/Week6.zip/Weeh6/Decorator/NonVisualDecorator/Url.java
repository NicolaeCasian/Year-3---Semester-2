public class Url extends Content{
    //Private String variable to hold the text
    private String txt;
    //Constructor that takes a String as a parameter
    Url(String txt){this.txt = txt;}
    //Method to display the text
    public void show(){System.out.println(txt);}
}
