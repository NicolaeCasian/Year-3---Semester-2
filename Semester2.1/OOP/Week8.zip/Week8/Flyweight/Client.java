import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.util.Vector;

public class Client extends JFrame implements MouseMotionListener {
   private Vector<String> names;
   private Vector<Button> buttons;
   private ButtonFactory fact;
   
   private final int Top = 30, Left = 30;
   private final int W = 50, H = 30;
   private final int VSpace = 80, HSpace = 70, HCount = 3;
   private String selectedName = "";
   
   public Client() {
      super("Flyweight Canvas");
      fact = new ButtonFactory();
      makeNames();
      makeFolders();
      
      // Adding an empty JPanel so the JFrame has a content pane
      JPanel jp = new JPanel();
      getContentPane().add(jp);
      
      setSize(new Dimension(300,300));
      addMouseMotionListener(this);
      setVisible(true);
      repaint();
   }
   
   private void makeFolders() {
      buttons = new Vector<Button>();
      for (int i = 0; i < names.size(); i++) {
         // Initially, add normal (unselected) buttons.
         buttons.add(fact.getButton(false));
      }
   }
   
   private void makeNames() {
      names = new Vector<String>();
      names.addElement("Add");
      names.addElement("Update");
      names.addElement("Delete");
      names.addElement("Find");
      selectedName = "";
   }
   
   @Override
   public void paint(Graphics g) {
      super.paint(g);  // Ensure proper painting of components
      
      Button f;
      String name;
      int j = 0;      // count number in row
      int row = Top;  // start in upper left
      int x = Left;
      
      // Draw all buttons with labels
      for (int i = 0; i < names.size(); i++) {
         name = names.elementAt(i);
         // Use the appropriate button instance based on selection
         if (name.equals(selectedName))
            f = fact.getButton(true);
         else
            f = fact.getButton(false);
         
         // Draw the button
         f.draw(g, x, row, name);
         
         x = x + HSpace; // Move to next horizontal position
         j++;
         if (j >= HCount) { // Reset for next row
            j = 0;
            row += VSpace;
            x = Left;
         }
      }
   }
   
   @Override
   public void mouseMoved(MouseEvent e) {
      int j = 0;      // count number in row
      int row = Top;  // start in upper left
      int x = Left;
      
      // Loop through button positions and check if the mouse is over one
      for (int i = 0; i < buttons.size(); i++) {
         Rectangle r = new Rectangle(x, row, W, H);
         if (r.contains(e.getX(), e.getY())) {
            // Set selectedName from the names vector
            selectedName = names.elementAt(i);
            repaint();
            return; // Exit after the first match
         }
         x = x + HSpace;
         j++;
         if (j >= HCount) {
            j = 0;
            row += VSpace;
            x = Left;
         }
      }
      // If the mouse is not over any button, clear selection.
      selectedName = "";
      repaint();
   }
   
   @Override
   public void mouseDragged(MouseEvent e) {
      // No action on drag
   }
   
   public static void main(String[] argv) {
      new Client();
   }
}
