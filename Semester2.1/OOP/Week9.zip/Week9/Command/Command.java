public interface Command
{
   //Execute command method
   public void Execute();
}
