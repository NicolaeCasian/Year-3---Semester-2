
//Client
public class GUIBuilder{
  //Imports the Attributes to build a window 
  public void buildWindow(AbstractWidgetFactory widgetFactory, String title){
    //Creates the window object for the GUI 
    Window window = widgetFactory.createWindow(title);
    window.repaint();
  }
}




