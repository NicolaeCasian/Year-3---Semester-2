public class UnixWidgetFactory extends AbstractWidgetFactory {
    public Window createWindow(String title){
        //Unix Specific behaviour
        UnixWindow window = new UnixWindow(title);
        return window;
      }
}
