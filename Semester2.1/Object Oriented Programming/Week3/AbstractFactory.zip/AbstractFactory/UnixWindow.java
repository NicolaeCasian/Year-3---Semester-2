public class UnixWindow extends Window {
    UnixWindow(String text){this.title = text;}

        public void repaint(){
             //MS Windows specific behaviour
            System.out.println("Title: " + title);
            System.out.println("Unix Style: Unix Window");
        }

}
