//Our Abstract Product
public abstract class Window{
    protected String title;
    public abstract void repaint();
}







